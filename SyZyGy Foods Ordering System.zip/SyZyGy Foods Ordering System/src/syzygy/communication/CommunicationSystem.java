/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package syzygy.communication;

import syzygy.model.Customer;

/**
 *
 * @author Sudeera Perera
 */
public class CommunicationSystem {
    public void communicateWithCustomer(Customer customer, String message) {
        // Implement communication logic
    }

    public void communicateWithOrderManager(OrderManager orderManager, String message) {
        // Implement communication logic
    }
}
