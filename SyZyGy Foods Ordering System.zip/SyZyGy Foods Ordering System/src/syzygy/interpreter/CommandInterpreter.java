/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package syzygy.interpreter;

import syzygy.model.Order;

/**
 *
 * @author Sudeera Perera
 */
public class CommandInterpreter {
     public void interpretCommand(String command, Order order) {
        // Parse and apply custom commands to the order
    }
}
